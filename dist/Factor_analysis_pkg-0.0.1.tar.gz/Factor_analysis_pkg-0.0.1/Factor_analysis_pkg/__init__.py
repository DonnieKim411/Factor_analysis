name = "Factor_analysis_pkg"
from .EM_Factor_analysis import factor_analysis
from .example import run_demo