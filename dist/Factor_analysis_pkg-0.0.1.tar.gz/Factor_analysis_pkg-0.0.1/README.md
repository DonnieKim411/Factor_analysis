# EM_Factor_Analysis Package

This is a EM Factor analysis package. 

EM_Factor_analysis takes input input of numpy array in float and number of factors to be considered and returns the factor loading matrix, latent variable, and log-likelihood history

example.py illustrates the usage of EM_Factor_analysis with IRIS dataset.